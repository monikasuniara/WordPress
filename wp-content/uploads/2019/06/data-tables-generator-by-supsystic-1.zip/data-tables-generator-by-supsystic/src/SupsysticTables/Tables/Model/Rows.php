<?php


class SupsysticTables_Tables_Model_Rows extends SupsysticTables_Core_BaseModel
{
}