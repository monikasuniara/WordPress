<?php return array(
    'promo_plugin_name'     => '',
    'promo_plugin_url'      => '',
    'promo_video_url'       => '',
    'promo_plugin_features' => array('%features%'),
);
